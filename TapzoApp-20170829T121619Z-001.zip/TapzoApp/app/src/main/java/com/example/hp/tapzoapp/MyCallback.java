package com.example.hp.tapzoapp;

import java.util.ArrayList;

 /**
  * Created by Sumit on 6/26/2017.
  */

 public interface MyCallback {
     void onSuccess(ArrayList<twitter4j.Status> result);
 }

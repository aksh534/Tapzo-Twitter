package com.example.hp.tapzoapp;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;

/**
 * Created by hp on 8/25/2017.
 */
public class showOnDate extends AppCompatActivity {

    TextView tv;
    ListView listView;
    Button button;
    String urlsArray[];

    private DatePickerActivity datePicker;
    private Calendar calendar;
    private int year, month, day;
    StringBuilder result = new StringBuilder("22-7-17") ;

    String userName[] , ids[] , url[] , profileUrls[] , date[];
    final Homepage homepage = new Homepage();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.on_date_layout);

        listView = (ListView) findViewById(R.id.listView);
        button = (Button) findViewById(R.id.button);

        calendar = Calendar.getInstance();
        year = calendar.get(Calendar.YEAR);

        month = calendar.get(Calendar.MONTH);
        day = calendar.get(Calendar.DAY_OF_MONTH);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String URL = url[position];
                Log.e("urlPosition", String.valueOf(position));

                Intent in = new Intent(Intent.ACTION_VIEW , Uri.parse(URL));

                startActivity(in);
            }
        });

    }

    @SuppressWarnings("deprecation")
    public void setDate(View view) {
        showDialog(999);
    }

    private void setDataInList() {
        userName = null; ids = null ; url = null; profileUrls = null ; date = null;
        Toast.makeText(this , "Date Selected is : "+result , Toast.LENGTH_LONG).show();
        homepage.getRecords(1, result.toString());
        userName = homepage.getUserNames();
        ids = homepage.getUserIds();
        url = homepage.getUrls();
        profileUrls = homepage.getProfileUrls();
        date = homepage.getDates();
        if(userName.length == 0) {
            Toast.makeText(this, "No Saved Bookmarks for " + result, Toast.LENGTH_LONG).show();
        }

        LazyAdapter adapter = new LazyAdapter(this, ids, userName, profileUrls, url, date);
        listView.setAdapter(adapter);
    }


    @Override
    protected Dialog onCreateDialog(int id) {
        // TODO Auto-generated method stub
        if (id == 999) {
            return new DatePickerDialog(this,
                    myDateListener, year, month, day);
        }
        return null;
    }

    private DatePickerDialog.OnDateSetListener myDateListener = new
            DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                    result = new StringBuilder().append(dayOfMonth).append("-")
                            .append(monthOfYear+1).append("-").append(String.valueOf(year).substring(2));
                    setDataInList();
                }
            };
}

package com.example.hp.tapzoapp;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.IntegerRes;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.twitter.sdk.android.core.Callback;
import com.twitter.sdk.android.core.Result;
import com.twitter.sdk.android.core.Twitter;
import com.twitter.sdk.android.core.TwitterException;
import com.twitter.sdk.android.core.models.Tweet;
import com.twitter.sdk.android.tweetui.CompactTweetView;
import com.twitter.sdk.android.tweetui.TweetUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import twitter4j.HttpParameter;
import twitter4j.Status;
import twitter4j.TwitterFactory;
import twitter4j.conf.ConfigurationBuilder;

/**
 * Created by hp on 8/24/2017.
 */
public class Homepage extends AppCompatActivity {

    ImageButton logout , bookmark , datePicker , userPicker , seeProfile;
    LinearLayout myLayout;

    public static SQLiteDatabase mydatabase;

    private static ArrayList<String> twitterIDs = new ArrayList<>();
    private static ArrayList<String> userName = new ArrayList<>();
    private static ArrayList<String> profileURLs = new ArrayList<>();
    private static ArrayList<String> listUrls = new ArrayList<>();
    private static ArrayList<String> date = new ArrayList<>();
    private static String TableName;

    static ArrayList<Long> tweetIds = new ArrayList<>();
    ProgressDialog mDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Twitter.initialize(this);
        setContentView(R.layout.homepage_activity);

        SessionManagement session = new SessionManagement(getApplicationContext());

        TableName = session.getTwitterId();
        mDialog = new ProgressDialog(this);
        mDialog.setMessage("Loading Data...");

        intialise_views();

        intialiseDatabase();

        checkConnectivity();


        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new SessionManagement(getApplicationContext()).logoutUser();
            }
        });

        datePicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(Homepage.this , showOnDate.class);
                startActivity(in);

            }
        });

        seeProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(Homepage.this , ProfilePage.class);
                 startActivity(in);

            }
        });

        userPicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent in = new Intent(Homepage.this , ListByUser.class);
                startActivity(in);

            }
        });

        bookmark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(Homepage.this, Bookmark.class);
                getAllRecord();

                in.putStringArrayListExtra("twitterIds", twitterIDs);
                in.putStringArrayListExtra("userName", userName);
                in.putStringArrayListExtra("profileURL", profileURLs);
                in.putStringArrayListExtra("URLs", listUrls);
                in.putStringArrayListExtra("date" , date);

                startActivity(in);
            }
        });

        if(Util.isConnected(getApplicationContext())) {

            new loadData().execute();
        }
        else{
            finish();
        }

    }

    private void checkConnectivity() {

        if(!Util.isConnected(this)){
            Toast.makeText(getApplicationContext() , "No Internet Connectivity" , Toast.LENGTH_LONG ).show();
            Intent in = new Intent(Homepage.this , Bookmark.class);

            getAllRecord();

            in.putStringArrayListExtra("twitterIds", twitterIDs);
            in.putStringArrayListExtra("userName" , userName);
            in.putStringArrayListExtra("profileURL" ,profileURLs );
            in.putStringArrayListExtra("URLs", listUrls);
            in.putStringArrayListExtra("date" , date);

            startActivity(in);
        }

    }

    private void intialiseDatabase() {

        mydatabase  = openOrCreateDatabase("Data", MODE_PRIVATE, null);
        mydatabase.execSQL("CREATE TABLE IF NOT EXISTS'"+ TableName +"'(TwitterId VARCHAR , TwitterName VARCHAR , profileURL VARCHAR , URL VARCHAR ,processDate VARCHAR);");

    }

    private void intialise_views() {

        logout = (ImageButton) findViewById(R.id.logout);
        bookmark = (ImageButton) findViewById(R.id.seeBookmark);
        datePicker = (ImageButton) findViewById(R.id.datePicker);
        seeProfile = (ImageButton) findViewById(R.id.seeProfile);
        userPicker = (ImageButton) findViewById(R.id.userPicker);
        myLayout = (LinearLayout) findViewById(R.id.tweetsParent);

    }

    public class loadData extends AsyncTask<Void , Void , ArrayList<Status>> {


        @Override
        protected void onPostExecute(ArrayList<twitter4j.Status> status) {
            mDialog.dismiss();
            ArrayList<twitter4j.Status> urls = new ArrayList<>();

            String regex = "\\(?\\b(https://|www[.])[-A-Za-z0-9+&amp;@#/%?=~_()|!:,.;]*[-A-Za-z0-9+&amp;@#/%=~_()|]";
            Pattern p = Pattern.compile(regex);

            for(twitter4j.Status st : status) {

                String string = st.getText();
                Matcher m = p.matcher(string);

                TweetUtils.loadTweet(st.getId() , new Callback<Tweet>() {
                    @Override
                    public void success(Result<Tweet> result) {
                        myLayout.addView(new CompactTweetView(Homepage.this, result.data));

                    }

                    @Override
                    public void failure(TwitterException exception) {

                    }
                });

                if (m.find()) {

                    urls.add(st);

                    String query = "INSERT INTO '"+TableName+"' VALUES('" + st.getUser().getScreenName() +
                            "','" + st.getUser().getName() +
                            "','" + st.getUser().getOriginalProfileImageURL() +
                            "','" + st.getText().substring(m.start(), m.end()) + "','" + String.valueOf(st.getCreatedAt().getDate())+"-"+String.valueOf(st.getCreatedAt().getMonth()+1 + "-" + String.valueOf(st.getCreatedAt().getYear()).substring(1)) + "');";


//                    Log.e("Date", String.valueOf(st.getCreatedAt().getDate()) + "-" + String.valueOf(st.getCreatedAt().getMonth() + 1) + "-" + String.valueOf(st.getCreatedAt().getYear()).substring(1));
                    //Log.e("TwitterID" , st.getUser().getScreenName());
//                    Log.e("urlPic", st.getUser().getOriginalProfileImageURL());

                    mydatabase.execSQL(query);

                }
            }
        }

        @Override
        protected ArrayList doInBackground(Void... params) {

            publishProgress();
            SessionManagement session = new SessionManagement(getApplicationContext());

            ConfigurationBuilder builder = new ConfigurationBuilder();
            builder.setDebugEnabled(true)
                    .setOAuthConsumerKey("ZMjolPOlgOliDT4LZfo0smRR3")
                    .setOAuthConsumerSecret("VrSCnqUPSighXI7Bz5bDaDf7sKShVaxIp7DPdDSRrbb3YnpDqR")
                    .setOAuthAccessToken(session.getAccessToken())
                    .setOAuthAccessTokenSecret(session.getSecretToken());

            TwitterFactory tf = new TwitterFactory(builder.build());

            twitter4j.Twitter twitter = tf.getInstance();

            ArrayList<twitter4j.Status> statuses = null;

            try{

                statuses = (ArrayList<twitter4j.Status>) twitter.timelines().getHomeTimeline();
                //Toast.makeText(LoginActivity.this, "" + statuses.size(), Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                e.printStackTrace();
            }

            return statuses;
        }

        @Override
        protected void onPreExecute() {
            mDialog.show();
        }

        @Override
        protected void onProgressUpdate(Void... values) {}
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return super.onCreateOptionsMenu(menu);
    }

    public void getDataOnDate(String onDate){

        String query = "SELECT * FROM '"+TableName+ "' WHERE processDate ='" + onDate + "'";
        Cursor c = mydatabase.rawQuery(query , null);
        twitterIDs.clear(); userName.clear(); profileURLs.clear(); listUrls.clear(); date.clear();

        while(c.moveToNext()){
            twitterIDs.add(c.getString(0));
            userName.add(c.getString(1));
            profileURLs.add(c.getString(2));
            listUrls.add(c.getString(3));
            date.add(c.getString(4));
        }

    }

    public void getRecords(int queryId , String extraData){
        if(queryId == 1)
            getDataOnDate(extraData);
        else
            getByUser(extraData);
    }

    public void getAllRecord(){

        String query = "SELECT * FROM '" + TableName + "'";
        Log.e("Query" , query);

        Cursor c = mydatabase.rawQuery(query , null);

        twitterIDs.clear(); userName.clear(); profileURLs.clear(); listUrls.clear(); date.clear();

        while(c.moveToNext()){
            twitterIDs.add(c.getString(0));
            userName.add(c.getString(1));
            profileURLs.add(c.getString(2));
            listUrls.add(c.getString(3));
            date.add(c.getString(4));

        }

    }

    public void getByUser(String user){
        String query = "SELECT * FROM '"+TableName+ "' WHERE TwitterId ='" + user + "'";
        Log.e("Query" , query);

        Cursor c = mydatabase.rawQuery(query , null);

        twitterIDs.clear(); userName.clear(); profileURLs.clear(); listUrls.clear(); date.clear();

        while(c.moveToNext()){
            twitterIDs.add(c.getString(0));
            userName.add(c.getString(1));
            profileURLs.add(c.getString(2));
            listUrls.add(c.getString(3));
            date.add(c.getString(4));
        }
    }


    public String[] getUserNames(){
        return userName.toArray(new String[userName.size()]);
    }

    public String[] getUserIds(){
        return twitterIDs.toArray(new String[twitterIDs.size()]);
    }

    public String[] getUrls(){
        return listUrls.toArray(new String[listUrls.size()]);
    }

    public String[] getProfileUrls(){
        return profileURLs.toArray(new String[profileURLs.size()]);
    }

    public String[] getDates(){
        return date.toArray(new String[date.size()]);
    }




    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 10 && resultCode == RESULT_OK){
            String onDate = data.getStringExtra("Date");
            Log.e("Date" , onDate);

            Intent in = new Intent(Homepage.this , showOnDate.class);

            getDataOnDate(onDate);

            in.putExtra("Date" , onDate);

            in.putStringArrayListExtra("twitterIds", twitterIDs);
            in.putStringArrayListExtra("userName" , userName);
            in.putStringArrayListExtra("profileURL" ,profileURLs );
            in.putStringArrayListExtra("URLs", listUrls);
            in.putStringArrayListExtra("date" , date);

            startActivity(in);
        }
    }
}

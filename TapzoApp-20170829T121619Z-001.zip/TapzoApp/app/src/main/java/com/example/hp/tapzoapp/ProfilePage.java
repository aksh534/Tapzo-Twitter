package com.example.hp.tapzoapp;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.squareup.picasso.Picasso;
import com.twitter.sdk.android.core.Callback;
import com.twitter.sdk.android.core.Result;
import com.twitter.sdk.android.core.Twitter;
import com.twitter.sdk.android.core.TwitterException;
import com.twitter.sdk.android.core.models.Tweet;
import com.twitter.sdk.android.tweetui.CompactTweetView;
import com.twitter.sdk.android.tweetui.TweetUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import twitter4j.Status;
import twitter4j.TwitterFactory;
import twitter4j.User;
import twitter4j.conf.ConfigurationBuilder;

/**
 * Created by hp on 8/27/2017.
 */
public class ProfilePage extends AppCompatActivity {

    TextView userName , userId , FollwersCount , FollowingCount , posts;
    ImageView profilePic;
    LinearLayout myLayout;

    static ArrayList<Long> tweetIds = new ArrayList<>();
    User userId1;
    ProgressDialog mDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Twitter.initialize(this);
        setContentView(R.layout.profile_page);

        userName = (TextView)findViewById(R.id.userName);
        userId = (TextView)findViewById(R.id.userID);
        FollwersCount = (TextView)findViewById(R.id.followers);
        FollowingCount = (TextView)findViewById(R.id.following);

        profilePic = (ImageView) findViewById(R.id.profile_picture);
        posts = (TextView)findViewById(R.id.posts);

        myLayout = (LinearLayout) findViewById(R.id.tweetsParent);

        mDialog = new ProgressDialog(this);
        mDialog.setMessage("Loading Data...");

        SessionManagement session = new SessionManagement(getApplicationContext());

        userName.setText(session.getUserName());
        userId.setText("@"+session.getTwitterId());

        FollwersCount.setText(session.getFollowersCount() + "\nFollowers");
        FollowingCount.setText(session.getFollowingCOunt() + "\nFollowing");

        Picasso.with(this)
                .load(session.getProfilePicURL())
                .into(profilePic);


        if(Util.isConnected(getApplicationContext())){
            new loadProfileData().execute();
        }

    }


    public class loadProfileData extends AsyncTask<Void , Void , ArrayList<Status>> {

//        MyCallback a;
//        loadProfileData(MyCallback b) {
//            a = b;
//        }

        @Override
        protected void onPostExecute(ArrayList<twitter4j.Status> status) {
            mDialog.dismiss();
            ArrayList<twitter4j.Status> urls = new ArrayList<>();

            posts.setText(status.size()+"\nPosts");

            for(twitter4j.Status st : status) {

                TweetUtils.loadTweet(st.getId(), new Callback<Tweet>() {
                            @Override
                            public void success(Result<Tweet> result) {
                                myLayout.addView(new CompactTweetView(ProfilePage.this, result.data));
                            }

                            @Override
                            public void failure(TwitterException exception) {

                            }
                        });

            }
//            a.onSuccess(urls);
       }

        @Override
        protected ArrayList doInBackground(Void... params) {

            SessionManagement session = new SessionManagement(getApplicationContext());
            Log.e("df" , session.getAccessToken());
            Log.e("dfsf" , session.getSecretToken());

            ConfigurationBuilder builder = new ConfigurationBuilder();
            builder.setDebugEnabled(true)
                    .setOAuthConsumerKey("ZMjolPOlgOliDT4LZfo0smRR3")
                    .setOAuthConsumerSecret("VrSCnqUPSighXI7Bz5bDaDf7sKShVaxIp7DPdDSRrbb3YnpDqR")
                    .setOAuthAccessToken(session.getAccessToken())
                    .setOAuthAccessTokenSecret(session.getSecretToken());

            TwitterFactory tf = new TwitterFactory(builder.build());

            twitter4j.Twitter twitter = tf.getInstance();

            ArrayList<twitter4j.Status> statuses = null;

            try{

                statuses = (ArrayList<twitter4j.Status>) twitter.timelines().getUserTimeline();
                //Toast.makeText(LoginActivity.this, "" + statuses.size(), Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                e.printStackTrace();
            }

            return statuses;
        }

        @Override
        protected void onPreExecute() {
            mDialog.show();
        }

        @Override
        protected void onProgressUpdate(Void... values) {}
    }


}

package com.example.hp.tapzoapp;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.DatePicker;
import android.widget.Toast;

import java.util.Calendar;


public class DatePickerActivity extends AppCompatActivity {
    private DatePickerActivity datePicker;
    private Calendar calendar;
    private int year, month, day;
    StringBuilder result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.date_picker);

        calendar = Calendar.getInstance();
        year = calendar.get(Calendar.YEAR);

        month = calendar.get(Calendar.MONTH);
        day = calendar.get(Calendar.DAY_OF_MONTH);
    }

    @SuppressWarnings("deprecation")
    public void setDate(View view) {
        showDialog(999);
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        // TODO Auto-generated method stub
        if (id == 999) {
            return new DatePickerDialog(this,
                    myDateListener, year, month, day);
        }
        return null;
    }

    private DatePickerDialog.OnDateSetListener myDateListener = new
            DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                    result = new StringBuilder().append(dayOfMonth).append("-")
                            .append(monthOfYear+1).append("-").append(String.valueOf(year).substring(2));
                }
            };


    @Override
    public void finish() {

        Intent intent = new Intent();
        Toast.makeText(this , result , Toast.LENGTH_LONG).show();
        intent.putExtra("Date", result.toString());
        setResult(RESULT_OK, intent);
        super.finish();
    }
}

package com.example.hp.tapzoapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;
import com.twitter.sdk.android.core.Callback;
import com.twitter.sdk.android.core.Result;
import com.twitter.sdk.android.core.Twitter;
import com.twitter.sdk.android.core.TwitterCore;
import com.twitter.sdk.android.core.TwitterException;
import com.twitter.sdk.android.core.TwitterSession;
import com.twitter.sdk.android.core.identity.TwitterLoginButton;
import com.twitter.sdk.android.core.models.User;

import retrofit2.Call;


public class LoginActivity extends AppCompatActivity {

    TwitterLoginButton tb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        requestWindowFeature(Window.FEATURE_NO_TITLE);
        Twitter.initialize(this);

        setContentView(R.layout.activity_login);


        final SessionManagement session = new SessionManagement(getApplicationContext());

        tb = (TwitterLoginButton)findViewById(R.id.twitter_login_button);

        tb.setCallback(new Callback<TwitterSession>() {
            @Override
            public void success(Result<TwitterSession> result) {

                Toast.makeText(LoginActivity.this , "Redirecting to Homepage..." , Toast.LENGTH_LONG ).show();

                Util.token = result.data.getAuthToken().token;
                Util.tokenSecret = result.data.getAuthToken().secret;


                Call<User> user = TwitterCore.getInstance().getApiClient().getAccountService().verifyCredentials(false, false,false);

                user.enqueue(new Callback<User>() {
                    @Override
                    public void success(Result<User> userResult) {


                        session.createLoginSession(userResult.data.name, userResult.data.screenName ,  userResult.data.profileImageUrl.replace("_normal", "") , Util.token, Util.tokenSecret ,
                                userResult.data.friendsCount , userResult.data.followersCount);
                        Intent in = new Intent(LoginActivity.this, Homepage.class);
                        startActivity(in);

                    }

                    @Override
                    public void failure(TwitterException exc) {
                        Log.d("TwitterKit", "Verify Credentials Failure", exc);
                    }
                });

        }

            @Override
            public void failure(TwitterException exception) {
                Toast.makeText(getApplicationContext() , "Authentication Failure" , Toast.LENGTH_SHORT).show();
            }
        });

    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Pass the activity result to the login button.
        tb.onActivityResult(requestCode, resultCode, data);
    }

}


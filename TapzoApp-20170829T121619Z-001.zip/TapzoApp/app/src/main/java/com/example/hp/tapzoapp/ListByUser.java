package com.example.hp.tapzoapp;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by hp on 8/28/2017.
 */
public class ListByUser extends AppCompatActivity {

    EditText editText;
    ImageButton button;
    ListView listView;
    String userName[] , ids[] , url[] , profileUrls[] , date[];
    final Homepage homepage = new Homepage();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.show_by_user);

        editText = (EditText) findViewById(R.id.userName);
        button = (ImageButton) findViewById(R.id.button);
        listView = (ListView) findViewById(R.id.listView);



        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                setDataInList();
            }
        });


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String URL = url[position];
                Log.e("urlPosition", String.valueOf(position));

                Intent in = new Intent(Intent.ACTION_VIEW , Uri.parse(URL));

                startActivity(in);
            }
        });

    }


    public void setDataInList(){

        String userId = editText.getText().toString();
        homepage.getRecords(2, userId);
        editText.setText(null);
        userName = homepage.getUserNames();
        ids = homepage.getUserIds();
        url = homepage.getUrls();
        profileUrls = homepage.getProfileUrls();
        date = homepage.getDates();
        if(userName.length == 0){
            Toast.makeText(this , "No BookMarks saved for "+ userId ,Toast.LENGTH_LONG).show();
        }

        LazyAdapter adapter = new LazyAdapter(this, ids, userName, profileUrls, url, date);
        listView.setAdapter(adapter);

    }
}

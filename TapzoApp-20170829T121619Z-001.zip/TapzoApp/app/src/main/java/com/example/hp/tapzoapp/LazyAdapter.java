package com.example.hp.tapzoapp;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;


import com.squareup.picasso.Picasso;


/**
 * Created by hp on 8/26/2017.
 */
public class LazyAdapter extends BaseAdapter {


    private Activity activity;
    private static LayoutInflater inflater = null;
    String[] ids , user , profile , url , dates;

    public LazyAdapter(Activity a , String twitterIds[] , String userName[] , String profileURLs[] , String urls[] , String date[]  ){

        activity = a;
        ids = twitterIds;
        user = userName;
        url = urls;
        profile = profileURLs;
        dates = date;
        inflater = (LayoutInflater)activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return ids.length;
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View vi = convertView;

        if(convertView == null)
            vi = inflater.inflate(R.layout.list_row , null);

        TextView userName = (TextView) vi.findViewById(R.id.userName);
        TextView userId = (TextView) vi.findViewById(R.id.userID);
        TextView urls = (TextView) vi.findViewById(R.id.url);
        TextView DateView = (TextView) vi.findViewById(R.id.dateView);

        ImageView profilePicture = (ImageView)vi.findViewById(R.id.list_image);

        userName.setText(user[position]);
        userId.setText("@"+ids[position]);
        urls.setText(url[position]);
        DateView.setText(dates[position]);

        Picasso.with(activity)
                .load(""+profile[position])
                .into(profilePicture);

        return vi;
    }
}

package com.example.hp.tapzoapp;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toolbar;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;


import java.util.ArrayList;

/**
 * Created by hp on 8/25/2017.
 */
public class Bookmark extends AppCompatActivity {

    ListView listView;
    String urlsArray[];
    SessionManagement session;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Twitter.initialize(this);
        setContentView(R.layout.bookmark_layout);

        listView = (ListView) findViewById(R.id.listView);
        session = new SessionManagement(getApplicationContext());

        Bundle bundle = getIntent().getExtras();

        ArrayList<String>twitterIds = bundle.getStringArrayList("twitterIds");
        ArrayList<String>userName = bundle.getStringArrayList("userName");
        ArrayList<String>profileURL = bundle.getStringArrayList("profileURL");
        ArrayList<String>listUrls = bundle.getStringArrayList("URLs");
        ArrayList<String>listDate = bundle.getStringArrayList("date");


        urlsArray = listUrls.toArray(new String[listUrls.size()]);

        LazyAdapter adapter = new LazyAdapter(this , twitterIds.toArray(new String[twitterIds.size()])
                                                ,userName.toArray(new String [userName.size()])
                                                ,profileURL.toArray(new String [profileURL.size()])
                                                ,listUrls.toArray(new String [listUrls.size()])
                                                ,listDate.toArray(new String [listDate.size()])
                                            );
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String URL = urlsArray[position];
                Log.e("urlPosition" , String.valueOf(position));

                Intent in = new Intent(Intent.ACTION_VIEW , Uri.parse(URL));

                startActivity(in);
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            session.logoutUser();
        }

        return super.onOptionsItemSelected(item);
    }


}

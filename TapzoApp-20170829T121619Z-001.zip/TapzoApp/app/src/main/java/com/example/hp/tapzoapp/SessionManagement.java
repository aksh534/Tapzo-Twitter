package com.example.hp.tapzoapp;;

import android.app.Activity;
import android.content.Intent;
import android.content.Context;;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.util.Log;

import java.util.HashMap;


/**
 * Created by hp on 8/24/2017.
 */
public class SessionManagement {

        SharedPreferences pref;
        Editor editor;

        Context _context;

        int PRIVATE_MODE = 0;

        private static final String PREF_NAME = "userCredentials";

        private static final String IS_LOGIN = "IsLoggedIn";

        public static final String ACCESS_TOKEN = "accessToken";

        public static final String SECRET_TOKEN = "secretToken";

        public static final String userName = "userName";

        public static final String twitterId = "twitterId";

        public static final String profilePicURL = "profilePicUrl" , FOLLOWERS_COUNT = "followers" , FOLLOWING_COUNT = "following";


    public SessionManagement(Context context){
            this._context = context;
            pref = _context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
            editor = pref.edit();
            Log.e("URL", profilePicURL);
            Log.e("ID", twitterId);
        }

        public void createLoginSession(String uName , String uID , String profileURL , String accessToken, String secretToken ,
                                       int following , int followers ){

            editor.putBoolean(IS_LOGIN, true);

            editor.putString(ACCESS_TOKEN, accessToken);

            editor.putString(SECRET_TOKEN, secretToken);

            editor.putString(userName, uName);

            editor.putString(twitterId, uID);

            editor.putString(profilePicURL, profileURL);

            editor.putInt(FOLLOWERS_COUNT, followers);

            editor.putInt(FOLLOWING_COUNT, following);




            editor.commit();
        }


        public void checkLogin(){

            if(!this.isLoggedIn()){

                Intent i = new Intent(_context, LoginActivity.class);

                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

                _context.startActivity(i);
            }
            else{

                Intent i = new Intent(_context , Homepage.class);

                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

                _context.startActivity(i);
            }

        }

        public void logoutUser(){
            editor.clear();
            editor.commit();

            Intent i = new Intent(_context, LoginActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

            _context.startActivity(i);
        }

        public boolean isLoggedIn(){
            return pref.getBoolean(IS_LOGIN, false);
        }

    public String getAccessToken(){
        return pref.getString(ACCESS_TOKEN, "");
    }

    public String getUserName() {
        return pref.getString(userName , "");
    }

    public String getTwitterId(){
        return pref.getString(twitterId , "");
    }

    public int getFollowersCount(){
        return pref.getInt(FOLLOWERS_COUNT , -1);
    }

    public int getFollowingCOunt(){
        return pref.getInt(FOLLOWING_COUNT, -1);
    }

    public String getProfilePicURL(){

        return pref.getString(profilePicURL , "");
    }

    public String getSecretToken(){
        return pref.getString(SECRET_TOKEN,"");
    }
}



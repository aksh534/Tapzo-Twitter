package com.example.hp.tapzoapp;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Base64;

/**
 * Created by Sumit on 8/23/2017.
 */

public  class Util {

    public static String token="";
    public static String tokenSecret="";
    public static String userName = "";
    public static String twitterId = "";

    public static String encodeBase64(String str){
        byte[]   bytesEncoded = str.getBytes();
        String base64 = Base64.encodeToString(bytesEncoded, Base64.DEFAULT);

        return base64;
    }

    public static boolean isConnected(Context ctx){
        boolean flag = false;
        ConnectivityManager connectivityManager =
                (ConnectivityManager) ctx.getSystemService(ctx.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

        if (networkInfo != null && networkInfo.isConnected()) {
            flag = true;
        }
        return flag;
    }


}
